---
layout: page
title: "0-Day/LKP Community User Guide"
footer: false
---

# 0-Day/LKP Community User Guide

## [Copyright](COPYING.html) 
## [Introduction](https://01.org/lkp/documentation/0-day-brief-introduction)
## Using LKP 
- [Use lkp-test for Linux kernel performance test](README.html) *- How to use the existing test cases to test Linux kernel*
- [How to add new test cases](lkp-howto.html)*- How to add your own test cases*
